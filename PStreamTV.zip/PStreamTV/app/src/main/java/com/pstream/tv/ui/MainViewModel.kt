package com.pstream.tv.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pstream.tv.data.model.Category
import com.pstream.tv.data.model.Movie
import com.pstream.tv.data.model.VideoSource
import com.pstream.tv.data.repository.MovieRepository
import kotlinx.coroutines.launch

sealed class UiState<out T> {
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

class MainViewModel : ViewModel() {

    private val repository = MovieRepository()

    private val _homeState = MutableLiveData<UiState<List<Category>>>()
    val homeState: LiveData<UiState<List<Category>>> = _homeState

    private val _searchState = MutableLiveData<UiState<List<Movie>>>()
    val searchState: LiveData<UiState<List<Movie>>> = _searchState

    private val _videoSources = MutableLiveData<UiState<List<VideoSource>>>()
    val videoSources: LiveData<UiState<List<VideoSource>>> = _videoSources

    init {
        loadHome()
    }

    fun loadHome() {
        _homeState.value = UiState.Loading
        viewModelScope.launch {
            repository.getHomeCategories()
                .onSuccess { _homeState.value = UiState.Success(it) }
                .onFailure { _homeState.value = UiState.Error(it.message ?: "Błąd połączenia") }
        }
    }

    fun search(query: String) {
        if (query.isBlank()) return
        _searchState.value = UiState.Loading
        viewModelScope.launch {
            repository.searchMovies(query)
                .onSuccess { _searchState.value = UiState.Success(it) }
                .onFailure { _searchState.value = UiState.Error(it.message ?: "Błąd wyszukiwania") }
        }
    }

    fun loadVideoSources(url: String) {
        _videoSources.value = UiState.Loading
        viewModelScope.launch {
            repository.getVideoSources(url)
                .onSuccess { _videoSources.value = UiState.Success(it) }
                .onFailure { _videoSources.value = UiState.Error(it.message ?: "Błąd ładowania") }
        }
    }
}
