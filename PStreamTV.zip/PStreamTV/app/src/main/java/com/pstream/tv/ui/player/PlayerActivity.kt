package com.pstream.tv.ui.player

import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.pstream.tv.R
import com.pstream.tv.data.model.VideoSource
import com.pstream.tv.ui.MainViewModel
import com.pstream.tv.ui.UiState

class PlayerActivity : FragmentActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var loadingIndicator: ProgressBar
    private lateinit var titleText: TextView
    private lateinit var errorText: TextView

    private var player: ExoPlayer? = null
    private lateinit var viewModel: MainViewModel

    companion object {
        const val EXTRA_MOVIE_URL = "movie_url"
        const val EXTRA_MOVIE_TITLE = "movie_title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.player_view)
        loadingIndicator = findViewById(R.id.loading_indicator)
        titleText = findViewById(R.id.title_text)
        errorText = findViewById(R.id.error_text)

        val movieUrl = intent.getStringExtra(EXTRA_MOVIE_URL) ?: run {
            finish()
            return
        }
        val movieTitle = intent.getStringExtra(EXTRA_MOVIE_TITLE) ?: ""
        titleText.text = movieTitle

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        setupObservers()
        viewModel.loadVideoSources(movieUrl)
    }

    private fun setupObservers() {
        viewModel.videoSources.observe(this) { state ->
            when (state) {
                is UiState.Loading -> {
                    loadingIndicator.visibility = View.VISIBLE
                    errorText.visibility = View.GONE
                }
                is UiState.Success -> {
                    loadingIndicator.visibility = View.GONE
                    if (state.data.isNotEmpty()) {
                        playSource(state.data.first())
                    } else {
                        showError("Nie znaleziono źródeł wideo.\nStrona może być niedostępna lub wymaga logowania.")
                    }
                }
                is UiState.Error -> {
                    loadingIndicator.visibility = View.GONE
                    showError("Błąd: ${state.message}")
                }
            }
        }
    }

    private fun playSource(source: VideoSource) {
        releasePlayer()

        player = ExoPlayer.Builder(this).build().also { exoPlayer ->
            playerView.player = exoPlayer

            val uri = Uri.parse(source.url)
            val mediaItem = when {
                source.url.contains(".m3u8") ->
                    MediaItem.Builder()
                        .setUri(uri)
                        .setMimeType(MimeTypes.APPLICATION_M3U8)
                        .build()
                source.url.contains(".mpd") ->
                    MediaItem.Builder()
                        .setUri(uri)
                        .setMimeType(MimeTypes.APPLICATION_MPD)
                        .build()
                else -> MediaItem.fromUri(uri)
            }

            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true

            exoPlayer.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_BUFFERING -> loadingIndicator.visibility = View.VISIBLE
                        Player.STATE_READY -> loadingIndicator.visibility = View.GONE
                        Player.STATE_ENDED -> finish()
                        Player.STATE_IDLE -> {}
                    }
                }

                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    showError("Błąd odtwarzania: ${error.message}")
                }
            })
        }
    }

    private fun showError(message: String) {
        errorText.text = message
        errorText.visibility = View.VISIBLE
        loadingIndicator.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                player?.let {
                    if (it.isPlaying) it.pause() else it.play()
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                player?.let {
                    if (it.isPlaying) it.pause() else it.play()
                }
                true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                player?.seekTo((player!!.currentPosition + 10_000).coerceAtMost(player!!.duration))
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                player?.seekTo((player!!.currentPosition - 10_000).coerceAtLeast(0))
                true
            }
            KeyEvent.KEYCODE_BACK -> {
                finish()
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }
}
