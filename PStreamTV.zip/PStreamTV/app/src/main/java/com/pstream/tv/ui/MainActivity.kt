package com.pstream.tv.ui

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.pstream.tv.R
import com.pstream.tv.ui.home.HomeFragment

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.main_container, HomeFragment())
                .commit()
        }
    }
}
