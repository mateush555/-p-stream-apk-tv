package com.pstream.tv.ui.search

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.leanback.app.SearchSupportFragment
import androidx.leanback.widget.*
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.pstream.tv.R
import com.pstream.tv.data.model.Movie
import com.pstream.tv.data.repository.MovieRepository
import com.pstream.tv.ui.home.MovieCardPresenter
import com.pstream.tv.ui.player.PlayerActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SearchActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.search_container, SearchFragment())
                .commit()
        }
    }
}

class SearchFragment : SearchSupportFragment(), SearchSupportFragment.SearchResultProvider {

    private val repository = MovieRepository()
    private val rowsAdapter = ArrayObjectAdapter(ListRowPresenter())
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setSearchResultProvider(this)

        setOnItemViewClickedListener { _, item, _, _ ->
            if (item is Movie) {
                val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_MOVIE_URL, item.detailUrl)
                    putExtra(PlayerActivity.EXTRA_MOVIE_TITLE, item.title)
                }
                startActivity(intent)
            }
        }
    }

    override fun getResultsAdapter(): ObjectAdapter = rowsAdapter

    override fun onQueryTextChange(newQuery: String): Boolean {
        searchJob?.cancel()
        searchJob = lifecycleScope.launch {
            delay(500) // debounce
            performSearch(newQuery)
        }
        return true
    }

    override fun onQueryTextSubmit(query: String): Boolean {
        searchJob?.cancel()
        lifecycleScope.launch { performSearch(query) }
        return true
    }

    private suspend fun performSearch(query: String) {
        if (query.length < 2) return
        rowsAdapter.clear()

        repository.searchMovies(query)
            .onSuccess { movies ->
                if (movies.isNotEmpty()) {
                    val listAdapter = ArrayObjectAdapter(MovieCardPresenter())
                    movies.forEach { listAdapter.add(it) }
                    rowsAdapter.add(ListRow(HeaderItem("Wyniki dla: $query"), listAdapter))
                }
            }
    }
}
