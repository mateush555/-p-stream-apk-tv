package com.pstream.tv.data.model

data class Movie(
    val id: String,
    val title: String,
    val description: String,
    val posterUrl: String,
    val backdropUrl: String,
    val year: String,
    val genre: String,
    val rating: String,
    val detailUrl: String,
    val type: ContentType = ContentType.MOVIE
)

data class VideoSource(
    val url: String,
    val label: String,
    val quality: String
)

enum class ContentType {
    MOVIE, SERIES
}

data class Category(
    val name: String,
    val movies: List<Movie>
)
