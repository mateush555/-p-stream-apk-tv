package com.pstream.tv.data.api

import com.pstream.tv.data.model.Movie
import com.pstream.tv.data.model.VideoSource
import com.pstream.tv.data.model.Category
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

class PStreamScraper {

    private val BASE_URL = "https://pstream.mov"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; TV) AppleWebKit/537.36 Chrome/91.0.4472.77 Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "pl-PL,pl;q=0.9,en;q=0.8")
                .header("Referer", BASE_URL)
                .build()
            chain.proceed(request)
        }
        .build()

    private fun fetchHtml(url: String): String? {
        return try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) response.body?.string() else null
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getHomePage(): List<Category> = withContext(Dispatchers.IO) {
        val html = fetchHtml(BASE_URL) ?: return@withContext emptyList()
        val doc = Jsoup.parse(html)
        val categories = mutableListOf<Category>()

        // Parse sections - selectors may need adjustment based on actual site structure
        val sections = doc.select("section, .section, .category, [class*='category'], [class*='section']")

        if (sections.isEmpty()) {
            // Fallback: get all movie cards from the page
            val movies = parseMovieCards(doc, BASE_URL)
            if (movies.isNotEmpty()) {
                categories.add(Category("Wszystkie filmy", movies))
            }
        } else {
            for (section in sections) {
                val title = section.select("h1, h2, h3, .title, .category-title").firstOrNull()?.text() ?: "Filmy"
                val movies = parseMovieCards(section, BASE_URL)
                if (movies.isNotEmpty()) {
                    categories.add(Category(title, movies))
                }
            }
        }

        // If still empty, try direct parsing
        if (categories.isEmpty()) {
            val movies = parseMovieCards(doc, BASE_URL)
            if (movies.isNotEmpty()) {
                categories.add(Category("Nowości", movies))
            }
        }

        categories
    }

    suspend fun searchMovies(query: String): List<Movie> = withContext(Dispatchers.IO) {
        val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
        val searchUrl = "$BASE_URL/search?q=$encodedQuery"
        val html = fetchHtml(searchUrl) ?: return@withContext emptyList()
        val doc = Jsoup.parse(html)
        parseMovieCards(doc, BASE_URL)
    }

    suspend fun getMovieDetails(detailUrl: String): Movie? = withContext(Dispatchers.IO) {
        val html = fetchHtml(detailUrl) ?: return@withContext null
        val doc = Jsoup.parse(html)

        try {
            val title = doc.select("h1, .title, [class*='title']").firstOrNull()?.text() ?: ""
            val description = doc.select(".description, .synopsis, .plot, p").firstOrNull()?.text() ?: ""
            val poster = doc.select("img[class*='poster'], img[class*='cover'], .poster img").firstOrNull()
                ?.attr("src")?.let { resolveUrl(it, BASE_URL) } ?: ""
            val year = doc.select("[class*='year'], .release").firstOrNull()?.text() ?: ""
            val genre = doc.select("[class*='genre'], .genre").firstOrNull()?.text() ?: ""
            val rating = doc.select("[class*='rating'], .imdb, .score").firstOrNull()?.text() ?: ""

            Movie(
                id = detailUrl.hashCode().toString(),
                title = title,
                description = description,
                posterUrl = poster,
                backdropUrl = poster,
                year = year,
                genre = genre,
                rating = rating,
                detailUrl = detailUrl
            )
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getVideoSources(detailUrl: String): List<VideoSource> = withContext(Dispatchers.IO) {
        val html = fetchHtml(detailUrl) ?: return@withContext emptyList()
        val sources = mutableListOf<VideoSource>()

        // Look for video sources in the HTML
        val doc = Jsoup.parse(html)

        // Find iframe sources
        doc.select("iframe").forEach { iframe ->
            val src = iframe.attr("src")
            if (src.isNotEmpty() && (src.contains("player") || src.contains("embed") || src.contains("stream"))) {
                sources.add(VideoSource(resolveUrl(src, BASE_URL), "Odtwarzacz 1", "Auto"))
            }
        }

        // Find direct video sources
        doc.select("video source, source[src]").forEach { source ->
            val src = source.attr("src")
            val label = source.attr("label").ifEmpty { "Źródło" }
            if (src.isNotEmpty()) {
                sources.add(VideoSource(resolveUrl(src, BASE_URL), label, source.attr("size").ifEmpty { "Auto" }))
            }
        }

        // Look for m3u8 in scripts
        val scriptContent = doc.select("script").joinToString(" ") { it.html() }
        val m3u8Regex = Regex("""["'](https?://[^"']+\.m3u8[^"']*)["']""")
        m3u8Regex.findAll(scriptContent).forEach { match ->
            sources.add(VideoSource(match.groupValues[1], "HLS Stream", "Auto"))
        }

        // Look for mp4 links
        val mp4Regex = Regex("""["'](https?://[^"']+\.mp4[^"']*)["']""")
        mp4Regex.findAll(scriptContent).forEach { match ->
            sources.add(VideoSource(match.groupValues[1], "MP4", "Auto"))
        }

        sources
    }

    private fun parseMovieCards(element: org.jsoup.nodes.Element, baseUrl: String): List<Movie> {
        val movies = mutableListOf<Movie>()

        // Common selectors for movie cards
        val cardSelectors = listOf(
            ".movie-card", ".film-card", ".item", ".card",
            "[class*='movie']", "[class*='film']", "[class*='poster']",
            "article", ".thumb"
        )

        var cards = element.select(cardSelectors.joinToString(", "))

        // If no cards found, try links with images
        if (cards.isEmpty()) {
            cards = element.select("a:has(img)")
        }

        for (card in cards.take(50)) { // limit to 50 per category
            try {
                val link = card.select("a").firstOrNull() ?: (if (card.tagName() == "a") card else continue)
                val href = link.attr("href").let { resolveUrl(it, baseUrl) }
                if (href.isEmpty() || href == baseUrl) continue

                val title = card.select(".title, h3, h2, h4, [class*='title'], [class*='name']")
                    .firstOrNull()?.text()
                    ?: link.attr("title")
                    ?: card.select("img").firstOrNull()?.attr("alt")
                    ?: ""

                if (title.isEmpty()) continue

                val img = card.select("img").firstOrNull()
                val posterUrl = (img?.attr("data-src") ?: img?.attr("src") ?: "")
                    .let { resolveUrl(it, baseUrl) }

                val year = card.select("[class*='year'], .year").firstOrNull()?.text() ?: ""
                val rating = card.select("[class*='rating'], .rating, .score").firstOrNull()?.text() ?: ""

                movies.add(
                    Movie(
                        id = href.hashCode().toString(),
                        title = title,
                        description = "",
                        posterUrl = posterUrl,
                        backdropUrl = posterUrl,
                        year = year,
                        genre = "",
                        rating = rating,
                        detailUrl = href
                    )
                )
            } catch (e: Exception) {
                continue
            }
        }

        return movies
    }

    private fun resolveUrl(url: String, baseUrl: String): String {
        return when {
            url.startsWith("http") -> url
            url.startsWith("//") -> "https:$url"
            url.startsWith("/") -> "$baseUrl$url"
            url.isEmpty() -> ""
            else -> "$baseUrl/$url"
        }
    }
}
