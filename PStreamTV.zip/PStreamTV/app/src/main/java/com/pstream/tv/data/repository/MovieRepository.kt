package com.pstream.tv.data.repository

import com.pstream.tv.data.api.PStreamScraper
import com.pstream.tv.data.model.Category
import com.pstream.tv.data.model.Movie
import com.pstream.tv.data.model.VideoSource

class MovieRepository {
    private val scraper = PStreamScraper()

    suspend fun getHomeCategories(): Result<List<Category>> = runCatching {
        scraper.getHomePage()
    }

    suspend fun searchMovies(query: String): Result<List<Movie>> = runCatching {
        scraper.searchMovies(query)
    }

    suspend fun getMovieDetails(url: String): Result<Movie?> = runCatching {
        scraper.getMovieDetails(url)
    }

    suspend fun getVideoSources(url: String): Result<List<VideoSource>> = runCatching {
        scraper.getVideoSources(url)
    }
}
