package com.pstream.tv.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.pstream.tv.R
import com.pstream.tv.data.model.Movie
import com.pstream.tv.ui.MainViewModel
import com.pstream.tv.ui.UiState
import com.pstream.tv.ui.player.PlayerActivity
import com.pstream.tv.ui.search.SearchActivity

class HomeFragment : BrowseSupportFragment() {

    private lateinit var viewModel: MainViewModel
    private lateinit var rowsAdapter: ArrayObjectAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        setupUI()
        setupObservers()
    }

    private fun setupUI() {
        title = "PStream TV"
        headersState = HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = true

        // Brand colors
        brandColor = ContextCompat.getColor(requireContext(), R.color.brand_color)
        searchAffordanceColor = ContextCompat.getColor(requireContext(), R.color.search_color)

        // Setup rows adapter
        rowsAdapter = ArrayObjectAdapter(ListRowPresenter())
        adapter = rowsAdapter

        // Search button
        setOnSearchClickedListener {
            startActivity(Intent(requireContext(), SearchActivity::class.java))
        }

        // Item click
        onItemViewClickedListener = OnItemViewClickedListener { _, item, _, _ ->
            if (item is Movie) {
                openPlayer(item)
            }
        }
    }

    private fun setupObservers() {
        viewModel.homeState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Loading -> showLoading()
                is UiState.Success -> {
                    rowsAdapter.clear()
                    state.data.forEach { category ->
                        val listRowAdapter = ArrayObjectAdapter(MovieCardPresenter())
                        category.movies.forEach { listRowAdapter.add(it) }
                        val header = HeaderItem(category.name)
                        rowsAdapter.add(ListRow(header, listRowAdapter))
                    }
                    if (state.data.isEmpty()) {
                        Toast.makeText(context, "Nie można pobrać zawartości. Sprawdź połączenie.", Toast.LENGTH_LONG).show()
                    }
                }
                is UiState.Error -> {
                    Toast.makeText(context, "Błąd: ${state.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showLoading() {
        rowsAdapter.clear()
        // Leanback shows spinner automatically when adapter is empty and fragment is loading
    }

    private fun openPlayer(movie: Movie) {
        val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_MOVIE_URL, movie.detailUrl)
            putExtra(PlayerActivity.EXTRA_MOVIE_TITLE, movie.title)
        }
        startActivity(intent)
    }
}
